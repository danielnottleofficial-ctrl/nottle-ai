"""NOTTLE AI test suite."""
